# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'

module TechnicalOffice
  module Tools
    VERSION = '0.6.7'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('مكتبة أدوات المكتب الفني', 'tot_tools/main')
      extension.description = 'Terrain, user profiles, architecture, vertex editing, subdivision, simplification and curve bending.'
      extension.version = VERSION
      extension.creator = 'م. جورج إسكندر — المكتب الفني لأعمال اللاندسكيب'
      extension.copyright = '2026 Technical Office'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
